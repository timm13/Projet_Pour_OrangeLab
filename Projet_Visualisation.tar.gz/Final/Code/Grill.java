import java.util.ArrayList;
import java.util.List;

public class Grill {
	private List<Point> points = new ArrayList<Point>();
	private int nLong;
	private int nLat;
	private double minLong;
	private double maxLong;
	private double minLat;
	private double maxLat;
	
	private List<Point> data = new ArrayList<Point>();
	private List<Point> isoValue = new ArrayList<Point>();
	
	//Constructor of Grill
	public Grill(int nLong, int nLat, double minLong, double minLat, double maxLong, double maxLat){
		this.nLong = nLong;
		this.nLat = nLat;
		this.minLat = minLat;
		this.maxLat = maxLat;
		this.minLong = minLong;
		this.maxLong = maxLong;
		
		double x = (maxLong-minLong)/(nLong-1);
		double y = (maxLat-minLat)/(nLat-1);
		
		//This loop will create all the points in the grill
		for(int i = 0; i < nLat; i++)
			for(int j = 0; j < nLong; j++){
				points.add(new Point((minLong + x*j),(minLat + y*i)));
			}
	}
	
	public int getSizePoints(){
		return points.size();
	}
	
	public int getSizeData(){
		return data.size();
	}
	
	public int getSizeIsoValue(){
		return isoValue.size();
	}
	
	public Point getPoint(int i, int j){
		return points.get(j*nLong+i);
	}
	
	//Overload the same method  
	public Point getPoint(int index){
		return points.get(index);
	}
	
	public double maxPM10(){
		double max = 0;
		for(int i=0; i < getSizePoints(); i++){
			if(getPoint(i).getPm10() > max)
				max = getPoint(i).getPm10();
		}
		return max;
	}
	
	public double minPM10(){
		double min = Double.MAX_VALUE;
		for(int i=0; i < getSizePoints(); i++){
			if(getPoint(i).getPm10() < min)
				min = getPoint(i).getPm10();
		}
		return min;
	}
	
	public void addData(Point point){
		data.add(point);
	}
	
	public Point getData(int index){
		return data.get(index);
	}
	
	public void addIsoValue(Point point){
		isoValue.add(point);
	}
	
	public void addIsoValue(List<Point> lp){
		isoValue.addAll(lp);
	}
	
	public Point getIso(int index){
		return isoValue.get(index);
	}

	public int getnLong() {
		return nLong;
	}

	public void setnLong(int nLong) {
		this.nLong = nLong;
	}

	public int getnLat() {
		return nLat;
	}

	public void setnLat(int nLat) {
		this.nLat = nLat;
	}

	public double getMinLong() {
		return minLong;
	}

	public void setMinLong(double minLong) {
		this.minLong = minLong;
	}

	public double getMaxLong() {
		return maxLong;
	}

	public void setMaxLong(double maxLong) {
		this.maxLong = maxLong;
	}

	public double getMinLat() {
		return minLat;
	}

	public void setMinLat(double minLat) {
		this.minLat = minLat;
	}

	public double getMaxLat() {
		return maxLat;
	}

	public void setMaxLat(double maxLat) {
		this.maxLat = maxLat;
	}
	
	public void printPoints(){
		for(Point p: points)
			System.out.println(p.getPm10());
	}
	
	public void printData(){
		for(Point p: data)
			System.out.println(p.getPm10());
	}
}
