
public class Point {
	private String nom;
	private double coordLat;
	private double coordLong;
	private double pm10;
	private String dataType;
	
	private int indicatif;
	
	public Point(double coordLong, double coordLat){
		this.coordLong = coordLong;
		this.coordLat = coordLat;
	}
	
	public Point(String nom, double coordLong, double coordLat,double pm10,String dataType){
		this.nom = nom;
		this.coordLong = coordLong;
		this.coordLat = coordLat;
		this.pm10 = pm10;
		this.dataType = dataType;
	}
	
	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public Point(String nom, int indicatif,double coordLong, double coordLat){
		this.nom = nom;
		this.indicatif = indicatif;
		this.coordLong = coordLong;
		this.coordLat = coordLat;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public double getCoordLat() {
		return coordLat;
	}

	public void setCoordLat(double coordLat) {
		this.coordLat = coordLat;
	}
	
	public double getCoordLong() {
		return coordLong;
	}

	public void setCoordLong(double coordLong) {
		this.coordLong = coordLong;
	}

	public double getPm10() {
		return pm10;
	}

	public void setPm10(double pm10) {
		this.pm10 = pm10;
	}

	public int getIndicatif() {
		return indicatif;
	}

	public void setIndicatif(int indicatif) {
		this.indicatif = indicatif;
	}
	
}
