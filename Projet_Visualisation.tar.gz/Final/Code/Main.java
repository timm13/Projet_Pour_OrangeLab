
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Placemarks();
		Shepard();
		Hardy();
	}
	
	//Fonction for the placemarks
	public static void Placemarks(){
		Grill g = new Grill(1000, 1000, 4.07, 44.30, 6.87, 46.22);
		Method.loadData(g,"/home/yang/Documents/Visu/Visu/data/Data_Time/data01082012000000.csv");
		Method.writePlacemarksKML("Placemarks.kml", g);
	}
	
	//Fonction for the methode Shepard
	public static void Shepard(){
		for(int i = 0; i <= 23; i++){
			Grill g = new Grill(1000, 1000, 4.07, 44.30, 6.87, 46.22);
			if(i <= 9){
				Method.loadData(g,"/home/yang/Documents/Visu/Visu/data/Data_Time/data010820120"+i+"0000.csv");
				Method.shepard(g, 2);
				//Method.shepard(g, 0.7);
				Image image = Method.imageRGB(g);
				Method.writeImagePPM("TestShepard"+i+".ppm", image);
			}else{
				Method.loadData(g,"/home/yang/Documents/Visu/Visu/data/Data_Time/data01082012"+i+"0000.csv");
				Method.shepard(g, 2);
				//Method.shepard(g, 0.7);
				Image image = Method.imageRGB(g);
				Method.writeImagePPM("TestShepard"+i+".ppm", image);
			}
			int j;
			for(j = 10; j<200; j += 10)
				g.addIsoValue(Method.marchingSquare(g, j));
			Method.writeIsoKML("TestShepardIso"+i+".kml", g);
		}
		Grill g = new Grill(1000, 1000, 4.07, 44.30, 6.87, 46.22);
		Method.writeImageKML("TestShepardImage.kml", g, "C:\\Users\\ensimag\\Downloads\\ShepardImage");
	}
	
	//Fonction for the methode Hardy
	public static void Hardy(){
		for(int i = 0; i <= 23; i++){
			Grill g = new Grill(1000, 1000, 4.07, 44.30, 6.87, 46.22);
			if(i <= 9){
				Method.loadData(g,"/home/yang/Documents/Visu/Visu/data/Data_Time/data010820120"+i+"0000.csv");
				Method.methodHardy(g, 0.001);
				//Method.methodHardy(g, 0.1);
				Image image = Method.imageRGB(g);
				Method.writeImagePPM("TestHardy"+i+".ppm", image);
			}else{
				Method.loadData(g,"/home/yang/Documents/Visu/Visu/data/Data_Time/data01082012"+i+"0000.csv");
				Method.methodHardy(g, 0.001);
				//Method.methodHardy(g, 0.1);
				Image image = Method.imageRGB(g);
				Method.writeImagePPM("TestHardy"+i+".ppm", image);
			}
			int j;
			for(j = 0; j<70; j += 8)
				g.addIsoValue(Method.marchingSquare(g, j));
			Method.writeIsoKML("TestHardyIso"+i+".kml", g);
		}
		Grill g = new Grill(1000, 1000, 4.07, 44.30, 6.87, 46.22);
		Method.writeImageKML("TestHardyImage.kml", g, "C:\\Users\\ensimag\\Downloads\\HardyImage");
	}

}
