import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Jama.Matrix;

public class Method {
	
		//Methode to read the data in .csv
		public static List<Point> readFile(String fileName){
				System.out.println(fileName);
				Scanner scanner;
				List<Point> value = new ArrayList<Point>();
				try{
					scanner = new Scanner(new FileReader(fileName));
					while(scanner.hasNextLine()){
						String l = scanner.nextLine();
						String[] ls = l.split(";");
						String name, dataType;
						double coordLat,coordLong,pm10;
						
						//Read name
						try{
							name = ls[0];
						}catch(Exception e){
							name = "";
						}
						//Read latitude
						try{
							coordLong = Double.parseDouble(ls[1]);
						}catch(Exception e){
							coordLong = 0.;
						}
						//Read longitude
						try{
							coordLat = Double.parseDouble(ls[2]);
						}catch(Exception e){
							coordLat = 0.;
						}
						//Read pm10
						try{
							pm10 = Double.parseDouble(ls[3]);
						}catch(Exception e){
							pm10 = 0.;
						}
						//Read dataType
                        try{
                            dataType = ls[4];
                        }catch(Exception e){
                            dataType = "";
                        }
                        value.add(new Point(name,coordLong,coordLat,pm10, dataType));
					}
				}catch (FileNotFoundException e) {
					System.out.println("It is fail to read " + fileName);
					System.out.println(e.getMessage());
					return value;
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("It is fail to read " + fileName);
					return value;
				}
				
				System.out.println("File loaded");
				return value;
		}
		
		public static void loadData(Grill g, String fileName){
			List<Point> value = readFile(fileName);
			for(Point p:value){
				g.addData(p);
			}
		}
		
		//Method to calculate the distance between two points
		public static double distancePoints(Point p1,Point p2){
			double distance = Math.sqrt(Math.pow(p2.getCoordLat()-p1.getCoordLat(), 2) 
					+ Math.pow(p2.getCoordLong()-p1.getCoordLong(), 2));
			return distance;
		}
		
		//Shepard method for one point in the grill
		public static void methodShepard(Grill g, int index, double u){
			double w;
			double distance;
			double res = 0; //ressource PM10
			double sumW = 0; 
			
			//calculate the PM10 for each point 
				for(int i = 0; i < g.getSizeData(); i++){
					distance = distancePoints(g.getPoint(index), g.getData(i));
					w = Math.pow(distance, -u);
					res += w * g.getData(i).getPm10();
					sumW += w;
				}
				//SumW is always the same value for each point
				//Times 1.5 is just for the colormap
				g.getPoint(index).setPm10(res/sumW*1.5);	
	}

		//Shepard method for every point in the grill
		public static void shepard(Grill g, double u){
			for(int i = 0; i < g.getSizePoints(); i++)
				methodShepard(g, i, u);
		}
		
		// Hardy method
		public static void methodHardy(Grill g,double r){
			double[][] H = new double[g.getSizeData()][g.getSizeData()];
			// Calculate the "distance" between data points (with correction R).
			// As matrix is symmetric, only calculation of half is required
			for(int i = 0; i< g.getSizeData(); i++){
				for(int j = i+1; j< g.getSizeData(); j++){
					H[i][j] = Math.sqrt(r + Math.pow(distancePoints(g.getData(i), g.getData(j)),2));
				}
			}
			int width = H.length;	
			
			//Mirror matrix to be symmetric
			for (int x = 0; x < width; x++) {
				for (int y = x + 1; y < width; y++) {
					H[y][x] = H[x][y];
				}
			}
			
			// Diagonal elements must be sqrt(R)
			for(int x = 0; x < width; x++){
				H[x][x] = Math.sqrt(r);
			}
			
			// H * alpha = g.getData(i) -> Solve inverse problem
			double[][] b = new double[g.getSizeData()][1];
			Matrix A = new Matrix(H);
			for(int i = 0;i<g.getSizeData();i++){
				b[i][0] = g.getData(i).getPm10();
			}
			Matrix c = new Matrix(b);
			Matrix alpha = A.solve(c);			
			
			double sumF;
			
			for(int i = 0; i < g.getSizePoints(); i++){
				sumF = 0;
				for(int j = 0;j<g.getSizeData();j++)
					sumF += Math.sqrt(r + Math.pow(distancePoints(g.getPoint(i), g.getData(j)),2)) * alpha.get(j, 0);			
				g.getPoint(i).setPm10(sumF);
			}
		}
							
		//Create the different points with different colors in the grill
		public static Image imageRGB(Grill g){
			Image image = new Image();
			image.setLargeur(g.getnLong());
			image.setHauteur(g.getnLat());
		
			for(int j = g.getnLat()-1; j>=0; j--){
				for(int i = 0; i<g.getnLong(); i++){
					double value = g.getPoint(i, j).getPm10();
										
					int[] color1 = new int[3];
                    int[] color2 = new int[3];
                    double ratio = 0;
                    
                    if(value < 12.5){
                        color1[0] = 0;
                        color1[1] = 0;
                        color1[2] = 143;
                        color2[0] = 0;
                        color2[1] = 0;
                        color2[2] = 255;
                        ratio = Math.max(0.0,value/12.5);
                    }
                     
                    if(value >= 12.5 && value < 37.5){
                        color1[0] = 0;
                        color1[1] = 0;
                        color1[2] = 255;
                        color2[0] = 0;
                        color2[1] = 255;
                        color2[2] = 255;
                        ratio = (value-12.5)/25;
                    }
                     
                    if(value >= 37.5 && value < 62.5){
                        color1[0] = 0;
                        color1[1] = 255;
                        color1[2] = 255;
                        color2[0] = 255;
                        color2[1] = 255;
                        color2[2] = 0;
                        ratio = (value-37.5)/25;
                    }
                     
                    if(value >= 62.5 && value < 87.5){
                        color1[0] = 255;
                        color1[1] = 255;
                        color1[2] = 0;
                        color2[0] = 255;
                        color2[1] = 0;
                        color2[2] = 0;
                        ratio = (value-62.5)/25;
                    }
                     
                    if(value >= 87.5){
                        color1[0] = 255;
                        color1[1] = 0;
                        color1[2] = 0;
                        color2[0] = 128;
                        color2[1] = 0;
                        color2[2] = 0;
                        ratio = Math.min(1.0,(value-87.5)/12.5);
                    }
                    image.ajouteRGB((int)((1-ratio)*color1[0]+ratio*color2[0]), (int)((1-ratio)*color1[1]+ratio*color2[1]), (int)((1-ratio)*color1[2]+ratio*color2[2]));
               	}		
			}
			return image;
		}
		
		public static boolean writePlacemarksKML(String fileName, Grill g){
			BufferedWriter bw;
			try {
				bw = new BufferedWriter(new FileWriter(fileName));
				bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
				bw.newLine();
				bw.write("<kml xmlns=\"http://www.opengis.net/kml/2.2\">");
				bw.newLine();
				bw.write("<Document>");
				bw.newLine();
				String nom = " ";
				for(int i = 0; i<g.getSizeData(); i++){
					if(nom != g.getData(i).getNom()){
						nom = g.getData(i).getNom();
						bw.write("<Placemark>");
						bw.newLine();
						bw.write("<name>"+ nom +"</name>");
						bw.newLine();
						bw.write("<Style>");
                        bw.newLine();
                        bw.write("<IconStyle>");
                        bw.newLine();
                        bw.write("<scale>2.5</scale>");
						bw.newLine();
                        bw.write("<Icon>");
                        bw.newLine();
                        if (g.getData(i).getDataType().equals("Urbain"))
                        	bw.write("<href>"+"http://www.iconspedia.com/dload.php?up_id=87814"+"</href>");
                        else if (g.getData(i).getDataType().equals("Trafic"))
                        	bw.write("<href>http://www.iconspedia.com/dload.php?up_id=225720</href>");
                        else if (g.getData(i).getDataType().equals("Périurbain"))
                        	bw.write("<href>http://www.iconspedia.com/dload.php?up_id=14757</href>");
                        else if (g.getData(i).getDataType().equals("Rurale nationale"))
                        	bw.write("<href>http://www.iconspedia.com/dload.php?up_id=78739</href>");
                        else if (g.getData(i).getDataType().equals("Industrielle"))
                        	bw.write("<href>http://www.iconspedia.com/dload.php?up_id=185674</href>");
                        bw.newLine();
                        bw.write("</Icon>");
                        bw.newLine();
                        bw.write("</IconStyle>");
                        bw.newLine();
                        bw.write("</Style>");
                        bw.newLine();
						bw.write("<Point>");
						bw.newLine();
						bw.write("<coordinates>"+g.getData(i).getCoordLong()+","+
								g.getData(i).getCoordLat()+","+g.getData(i).getPm10()+"</coordinates>");
						bw.newLine();
						bw.write("</Point>");
						bw.newLine();
						bw.write("</Placemark>");
						bw.newLine();
					}
				}
				bw.write("</Document>");
				bw.newLine();
				bw.write("</kml>");
				bw.close(); 
				System.out.println(fileName + " is writen successfully");
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
				System.out.println("It is fail to write " + fileName);
				return false;
			}  
		}

		public static boolean writeImagePPM(String fileName, Image image){
			BufferedWriter bw;
			try {
				bw = new BufferedWriter(new FileWriter(fileName));
				bw.write("P3");
				bw.newLine();
				bw.write("# " + fileName);
				bw.newLine();
				bw.write(String.valueOf(image.getLargeur()));
				bw.write(" ");
				bw.write(String.valueOf(image.getHauteur()));
				bw.newLine();
				image.updateMaxValue();
				bw.write(String.valueOf(image.updateMaxValue()));
				bw.newLine();
				for(int i=0; i<image.sizeBuffer(); i++){
					bw.write(String.valueOf(image.getRed(i)));
					bw.write(" ");
					bw.write(String.valueOf(image.getGreen(i)));
					bw.write(" ");
					bw.write(String.valueOf(image.getBlue(i)));
					bw.newLine();
				}
				bw.close(); 
				System.out.println(fileName + " is writen successfully");
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
				System.out.println("It is fail to write " + fileName);
				return false;
			}  
		}
		
		public static boolean writeImageKML(String fileName, Grill g, String image){
			BufferedWriter bw;
			try {
					bw = new BufferedWriter(new FileWriter(fileName));
					bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
					bw.newLine();
					bw.write("<kml xmlns=\"http://www.opengis.net/kml/2.2\" xmlns:gx=\"http://www.google.com/kml/ext/2.2\">");
					bw.newLine();
					bw.write("<Document>");
					bw.newLine();
					for(int i = 0; i <= 23; i++){
						bw.write("<GroundOverlay>");
						bw.newLine();
						bw.write("<name>"+"PM10"+"</name>");
						bw.newLine();
						bw.write("<gx:TimeSpan>");
						bw.newLine();
						if(i < 9){
							bw.write("<begin>2012-08-01T0"+i+":00:00</begin>");
							bw.newLine();
							bw.write("<end>2012-08-01T0"+(i+1)+":00:00</end>");
							bw.newLine();
						}else if(i == 9){
							bw.write("<begin>2012-08-01T0"+i+":00:00</begin>");
							bw.newLine();
							bw.write("<end>2012-08-01T"+(i+1)+":00:00</end>");
							bw.newLine();
						}else{
							bw.write("<begin>2012-08-01T"+i+":00:00</begin>");
							bw.newLine();
							bw.write("<end>2012-08-01T"+(i+1)+":00:00</end>");
							bw.newLine();
						}
						bw.write("</gx:TimeSpan>");
						bw.newLine();
						bw.write("<color>red</color>");
						bw.newLine();
						bw.write("<Icon>");
						bw.newLine();
						bw.write("<href>"+image+i+".jpg</href>");
						bw.newLine();
						bw.write("</Icon>");
						bw.newLine();
						bw.write("<LatLonBox>");
						bw.newLine();
						bw.write("<north>"+g.getMaxLat()+"</north>");
						bw.newLine();
						bw.write("<south>"+g.getMinLat()+"</south>");
						bw.newLine();
						bw.write("<east>"+g.getMaxLong()+"</east>");
						bw.newLine();
						bw.write("<west>"+g.getMinLong()+"</west>");
						bw.newLine();
						bw.write("</LatLonBox>");
						bw.newLine();
						bw.write("</GroundOverlay>");
						bw.newLine();
					}
					bw.write("</Document>");
					bw.newLine();
					bw.write("</kml>");
					bw.close();
				System.out.println(fileName + " is writen successfully");
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
				System.out.println("It is fail to write " + fileName);
				return false;
			}  
		}
		
		//Method to compute the barycenter between two points
		public static Point barycenter(Point p1, Point p2, double isoValue){
			double lambda = (isoValue-p1.getPm10())/(p2.getPm10()-p1.getPm10());
			Point point = new Point((1-lambda)*p1.getCoordLong()+lambda*p2.getCoordLong(),
					(1-lambda)*p1.getCoordLat()+lambda*p2.getCoordLat());
			point.setPm10(isoValue);
			return point;	
		}
		
		/** All cases

		/// Case 0   Case 1   Case 2   Case 3   Case 4   Case 5   Case 6   Case 7
		/// O-----O  O-----O  O-----O  O-----O  O-----#  #-----O  O-----#  O-----#
		/// |     |  |     |  |     |  |     |  |    \|  |    \|  |  |  |  |/    |
		/// |     |  |\    |  |    /|  |-----|  |     |  |\    |  |  |  |  |     |
		/// O-----O  #-----O  O-----#  #-----#  O-----O  O-----#  O-----#  #-----#
		///
		/// Case 8   Case 9   Case 10  Case 11  Case 12  Case 13  Case 14  Case 15
		/// #-----O  #-----O  O-----#  #-----O  #-----#  #-----#  #-----#  #-----#
		/// |/    |  |  |  |  |/    |  |    \|  |-----|  |     |  |     |  |     |
		/// |     |  |  |  |  |    /|  |     |  |     |  |    /|  |\    |  |     |
		/// O-----O  #-----O  #-----O  #-----#  O-----O  #-----O  O-----#  #-----#

		   Algorithm by http://users.polytech.unice.fr/~lingrand/MarchingCubes/algo.html
		**/
		public static List<Point> marchingSquareMethod(Point p1, Point p2, Point p3, Point p4,double isoValue){
			List<Point> values = new ArrayList<Point>();
			double v1, v2, v3, v4;
			v1 = p1.getPm10();
			v2 = p2.getPm10();
			v3 = p3.getPm10();
			v4 = p4.getPm10();
			
			//case 1
			if(v1<isoValue && v2<isoValue && v3<isoValue && v4>=isoValue){
				values.add(barycenter(p1,p4,isoValue));
				values.add(barycenter(p3,p4,isoValue));
			}
			//case 2
			if(v1<isoValue && v2<isoValue && v3>=isoValue && v4<isoValue){
				values.add(barycenter(p2,p3,isoValue));
				values.add(barycenter(p3,p4,isoValue));
			}
			//case 3
			if(v1<isoValue && v2<isoValue && v3>=isoValue && v4>=isoValue){
				values.add(barycenter(p2,p3,isoValue));
				values.add(barycenter(p1,p4,isoValue));
			}
			//case 4
			if(v1<isoValue && v2>=isoValue && v3<isoValue && v4<isoValue){
				values.add(barycenter(p1,p2,isoValue));
				values.add(barycenter(p2,p3,isoValue));
			}
			//case 5
			if(v1>=isoValue && v2<isoValue && v3>=isoValue && v4<isoValue){
				if((v1+v2+v3+v4)/4 >= isoValue){
					values.add(barycenter(p4, p1, isoValue));
					values.add(barycenter(p4, p3, isoValue));
					values.add(barycenter(p2, p1, isoValue));
					values.add(barycenter(p2, p3, isoValue));
				}else{
					values.add(barycenter(p2, p1, isoValue));
					values.add(barycenter(p4, p1, isoValue));
					values.add(barycenter(p2, p3, isoValue));
					values.add(barycenter(p4, p3, isoValue));
				}
			}
			//case 6
			if(v1<isoValue && v2>=isoValue && v3>=isoValue && v4<isoValue){
				values.add(barycenter(p1,p2,isoValue));
				values.add(barycenter(p3,p4,isoValue));
			}
			//case 7
			if(v1<isoValue && v2>=isoValue && v3>=isoValue && v4>=isoValue){
				values.add(barycenter(p1,p2,isoValue));
				values.add(barycenter(p1,p4,isoValue));
			}
			//case 8
			if(v1>=isoValue && v2<isoValue && v3<isoValue && v4<isoValue){
				values.add(barycenter(p1,p2,isoValue));
				values.add(barycenter(p1,p4,isoValue));
			}
			//case 9
			if(v1>=isoValue && v2<isoValue && v3<isoValue && v4>=isoValue){
				values.add(barycenter(p1,p2,isoValue));
				values.add(barycenter(p3,p4,isoValue));
			}
			//case 10
			if(v1<isoValue && v2>=isoValue && v3<isoValue && v4>=isoValue){
				if((v1+v2+v3+v4)/4 >= isoValue){
					values.add(barycenter(p1, p2, isoValue));
					values.add(barycenter(p1, p4, isoValue));
					values.add(barycenter(p3, p2, isoValue));
					values.add(barycenter(p3, p4, isoValue));
				}else{
					values.add(barycenter(p1, p2, isoValue));
					values.add(barycenter(p3, p2, isoValue));
					values.add(barycenter(p1, p4, isoValue));
					values.add(barycenter(p3, p4, isoValue));
				}
			}
			//case 11
			if(v1>=isoValue && v2<isoValue && v3>=isoValue && v4>=isoValue){
				values.add(barycenter(p1,p2,isoValue));
				values.add(barycenter(p2,p3,isoValue));
			}
			//case 12
			if(v1>=isoValue && v2>=isoValue && v3<isoValue && v4<isoValue){
				values.add(barycenter(p2,p3,isoValue));
				values.add(barycenter(p1,p4,isoValue));
			}
			//case 13
			if(v1>=isoValue && v2>=isoValue && v3<isoValue && v4>=isoValue){
				values.add(barycenter(p2,p3,isoValue));
				values.add(barycenter(p3,p4,isoValue));
			}
			//case 14
			if(v1>=isoValue && v2>=isoValue && v3>=isoValue && v4<isoValue){
				values.add(barycenter(p1,p4,isoValue));
				values.add(barycenter(p3,p4,isoValue));
			}
			return values;
		}
		
		public static List<Point> marchingSquare(Grill g, double isoValue){
			List<Point> values = new ArrayList<Point>();
			for(int j = 0; j<g.getnLat()-1; j++)
				for(int i = 0; i<g.getnLong()-1; i++)
					values.addAll(marchingSquareMethod(g.getPoint(i, j), g.getPoint(i, j+1), g.getPoint(i+1, j+1), g.getPoint(i+1, j), isoValue));
			return values;
		}
		
		
		public static boolean writeIsoKML(String fileName, Grill g){
			BufferedWriter bw;
			try {
				bw = new BufferedWriter(new FileWriter(fileName));
				bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
				bw.newLine();
				bw.write("<kml xmlns=\"http://www.opengis.net/kml/2.2\">");
				bw.newLine();
				bw.write("<Document>");
				bw.newLine();
				bw.write("<Style id=\"transPurpleLineGreenPoly\">");
				bw.newLine();
				bw.write("<LineStyle>");
				bw.newLine();
				bw.write("<color>ff000000</color>");
				bw.newLine();
				bw.write("<width>2</width>");
				bw.newLine();
				bw.write("</LineStyle>");
				bw.newLine();
				bw.write("<PolyStyle>");
				bw.newLine();
				bw.write("<color>7f00ff00</color>");
				bw.newLine();
				bw.write("</PolyStyle>");
				bw.newLine();
				bw.write("</Style>");
				bw.newLine();
				for(int i = 0; i<g.getSizeIsoValue(); i++){
					bw.write("<Placemark>");
					bw.newLine();
					bw.write("<name>PM10 isoValue</name>");
					bw.newLine();
					bw.write("<styleUrl>#transPurpleLineGreenPoly</styleUrl>");
					bw.newLine();
					bw.write("<LineString>");
					bw.newLine();
					bw.write("<tessellate>1</tessellate>");
					bw.newLine();
					bw.write("<altitudeMode>Relative</altitudeMode>");
					//bw.write("<altitudeMode>Absolute</altitudeMode>");
					bw.newLine();
					bw.write("<coordinates>");
					bw.newLine();
					bw.write(g.getIso(i).getCoordLong()+","+g.getIso(i).getCoordLat()+","+0);
					bw.newLine();
					bw.write(g.getIso(i+1).getCoordLong()+","+g.getIso(i+1).getCoordLat()+","+0);
					bw.newLine();
					bw.write("</coordinates>");
					bw.newLine();
					bw.write("</LineString>");
					bw.newLine();
					bw.write("</Placemark>");
					bw.newLine();
					i++;
				}
				bw.write("</Document>");
				bw.newLine();
				bw.write("</kml>");
				bw.close(); 
				System.out.println(fileName + " is writen successfully");
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
				System.out.println("It is fail to write " + fileName);
				return false;
			}  
		}
}
