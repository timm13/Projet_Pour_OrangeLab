import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Image {
	private String nom;
	private double largeur = 0;
	private double hauteur = 0;
	private double maxValue = 0;
	
	private List<Integer> redBuffer = new ArrayList<Integer>();
	private List<Integer> greenBuffer = new ArrayList<Integer>();
	private List<Integer> blueBuffer = new ArrayList<Integer>();
	
	public Image() {
		// TODO Auto-generated constructor stub
	}
	
	public Image(Image image){
		this.nom = image.getNom();
		this.largeur = image.getLargeur();
		this.hauteur = image.getHauteur();
		this.maxValue = image.getMaxValue();
		
		this.redBuffer.addAll(image.getRedBuffer());
		this.greenBuffer.addAll(image.getGreenBuffer());
		this.blueBuffer.addAll(image.getBlueBuffer());
	}
	
	public int sizeBuffer(){
		//Because the three Buffer have the same size, we just choose one buffer
		return this.redBuffer.size();
	}
	
	public void ajouteRGB(int red, int green, int blue){
		this.redBuffer.add(red);
		this.greenBuffer.add(green);
		this.blueBuffer.add(blue);
	}

	//Set the collection of the three colors
	public void setRed(int index, int value){
		this.redBuffer.add(index, value);
	}
	
	public int getRed(int index){
		return this.redBuffer.get(index);
	}
	
	public void setGreen(int index, int value){
		this.greenBuffer.add(index, value);
	}
	
	public int getGreen(int index){
		return this.greenBuffer.get(index);
	}
	
	public void setBlue(int index, int value){
		this.blueBuffer.add(index, value);
	}
	
	public int getBlue(int index){
		return this.blueBuffer.get(index);
	}
	
	public void setImageRGB(int index, int red, int green, int blue){
		this.setRed(index, red);
		this.setGreen(index, green);
		this.setBlue(index, blue);
	}
	
	//Get the max value among the three colors
	public double updateMaxValue(){
		maxValue = Collections.max(redBuffer);
		
		if(maxValue < Collections.max(greenBuffer))
			maxValue = Collections.max(greenBuffer);
		if(maxValue < Collections.max(blueBuffer))
			maxValue = Collections.max(blueBuffer);
		return maxValue;
	}
	
	//Setter and getter of this class
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public double getLargeur() {
		return largeur;
	}

	public void setLargeur(double largeur) {
		this.largeur = largeur;
	}

	public double getHauteur() {
		return hauteur;
	}

	public void setHauteur(double hauteur) {
		this.hauteur = hauteur;
	}

	public double getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(double maxValue) {
		this.maxValue = maxValue;
	}

	public List<Integer> getRedBuffer() {
		return redBuffer;
	}

	public void setRedBuffer(List<Integer> redBuffer) {
		this.redBuffer = redBuffer;
	}

	public List<Integer> getGreenBuffer() {
		return greenBuffer;
	}

	public void setGreenBuffer(List<Integer> greenBuffer) {
		this.greenBuffer = greenBuffer;
	}

	public List<Integer> getBlueBuffer() {
		return blueBuffer;
	}

	public void setBlueBuffer(List<Integer> blueBuffer) {
		this.blueBuffer = blueBuffer;
	}
	
}
